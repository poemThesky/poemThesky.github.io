-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2019 年 04 月 29 日 16:24
-- 服务器版本: 5.5.53
-- PHP 版本: 5.4.45

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `grade`
--

-- --------------------------------------------------------

--
-- 表的结构 `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL,
  `name` char(50) DEFAULT NULL,
  `pass` char(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `admins`
--

INSERT INTO `admins` (`id`, `name`, `pass`) VALUES
(1001, 'admin', 'admin001');

-- --------------------------------------------------------

--
-- 表的结构 `classes`
--

CREATE TABLE IF NOT EXISTS `classes` (
  `id` int(11) NOT NULL,
  `classname` char(50) DEFAULT NULL,
  `teacher` char(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `classes`
--

INSERT INTO `classes` (`id`, `classname`, `teacher`) VALUES
(20150101, 'english', 'fengwanzhong'),
(20150102, 'networks', 'yunankun');

-- --------------------------------------------------------

--
-- 表的结构 `english`
--

CREATE TABLE IF NOT EXISTS `english` (
  `id` int(11) NOT NULL,
  `name` char(50) DEFAULT NULL,
  `grade` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `english`
--

INSERT INTO `english` (`id`, `name`, `grade`) VALUES
(3001, 'yiz', 86),
(3002, 'erz', 75),
(3003, 'sanz', 90),
(3004, 'siz', 60),
(3005, 'wuz', 67),
(3006, 'liuz', 50),
(3007, 'qiz', 56),
(3008, 'baz', 56),
(3009, 'jiu', 56),
(3010, 'shiz', 56);

-- --------------------------------------------------------

--
-- 表的结构 `networks`
--

CREATE TABLE IF NOT EXISTS `networks` (
  `id` int(11) NOT NULL,
  `name` char(50) DEFAULT NULL,
  `grade` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `networks`
--

INSERT INTO `networks` (`id`, `name`, `grade`) VALUES
(3001, 'yiz', 56),
(3002, 'erz', 80),
(3003, 'sanz', 93),
(3004, 'siz', 91),
(3005, 'wuz', 48),
(3006, 'liuz', 78),
(3007, 'qiz', 78),
(3008, 'baz', 78),
(3009, 'jiuz', 78),
(3010, 'shiz', 78);

-- --------------------------------------------------------

--
-- 表的结构 `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `id` int(11) NOT NULL,
  `name` char(50) DEFAULT NULL,
  `pass` char(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `students`
--

INSERT INTO `students` (`id`, `name`, `pass`) VALUES
(3001, 'yiz', 'yi001'),
(3002, 'erz', 'er002'),
(3003, 'sanz', 'san003'),
(3004, 'siz', 'si004'),
(3005, 'wuz', 'wu005'),
(3006, 'liuz', 'liu006'),
(3007, 'qiz', 'qi007'),
(3008, 'baz', 'ba008'),
(3009, 'jiuz', 'jiu009'),
(3010, 'shiz', 'shi010');

-- --------------------------------------------------------

--
-- 表的结构 `teachers`
--

CREATE TABLE IF NOT EXISTS `teachers` (
  `id` int(11) NOT NULL,
  `name` char(50) DEFAULT NULL,
  `pass` char(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `teachers`
--

INSERT INTO `teachers` (`id`, `name`, `pass`) VALUES
(2001, 'fengwanzhong', 'feng001'),
(2002, 'yunankun', 'yu002');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

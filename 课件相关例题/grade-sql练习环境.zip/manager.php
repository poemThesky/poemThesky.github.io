<?php
  session_start();
  if(!isset($_SESSION['valid_id']))
    header("Location:login.html");
  print("��ӭ����Ա��".$_SESSION['valid_name']);
  print('<form method="post" action="logout.php">');
  print('<input type="submit" value="�˳���¼"/>');
  print('</form>');
?>
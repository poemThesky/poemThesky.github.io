<?php
  session_start();
  unset($_SESSION['valid_id']);
  unset($_SESSION['valid_name']);
  session_destroy();
  header("Location:login.html");
?>
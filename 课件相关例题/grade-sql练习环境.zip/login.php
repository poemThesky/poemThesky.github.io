<?php
  function back(){
   print('<form action="logout.php" method="get">');
   print('<input type="submit" value="<<����"/> ');
   print('</form>');
  }
  $id=$_POST['user'];
  $pass=$_POST['pass'];
  $type=$_POST['type'];
  switch($type)
  {
    case "student":  //ѧ��
      $t_name="students";
      $loc="student.php";
      break;
    case "teacher":  //��ʦ
      $t_name="teachers";
      $loc="teacher.php";
      break;
    case "manager":   //����Ա
      $t_name="admins";
      $loc="manager.php";
   }
   session_start();
   $db=mysql_connect('127.0.0.1','root','123456');
   if(!$db)
   {
     print("�������ݿ����......<br>");
     back();
     exit;
   }
   mysql_select_db('grade',$db);
   if(mysql_errno($db))
   {
     print("ʹ�����ݿ������......<br>");
     back();
     exit;
    }
    $query="select * from ".$t_name." where id='".$id."'"." and pass='".$pass."'";
    $result=mysql_query($query,$db);
    if(!$result)
    {
      print("���ݿ��ѯ����......<br>");
      mysql_close($db);
      back();
      exit;
     }
     $value=mysql_fetch_array($result);
     if($value==null)
     {
      print("ѧ��/���Ż��������......<br>");
      mysql_close($db);
      back();
      exit;
     }
     $name=$value['name'];
     $_SESSION['valid_id']=$id;
     $_SESSION['valid_name']=$name;
     //��ҳ�ض��򵽲�ͬ�����˻�
     header("Location:".$loc);
?>
<?php
  session_start();
  if(!isset($_SESSION['valid_id']))
  {
    header("Location:login.html");
    exit;
   }
  print("<br>��ӭ��ʦ��".$_SESSION['valid_name']."<br><br>");

  //��ʾ��ʦ�Ŀγ̳ɼ�
  $db=mysql_connect('127.0.0.1','root','123456');
  if(!$db)
  {
    print("�������ݿ����......<br>");
    exit;
   }
   mysql_select_db('grade',$db);
   if(mysql_errno($db))
   {
     print("ʹ�����ݿ������......<br>");
     exit;
   }

   $name=$_SESSION['valid_name'];
   $query="select * from classes where teacher='".$name."'";
   //print($query."<br>");
   $result=mysql_query($query,$db);
   if(!$result)
   {
      print("���ݿ��ѯ����......<br>");
      mysql_close($db);
      back();
      exit;
    }

    $value=mysql_fetch_array($result);
    $class=$value['classname'];

   if(isset($_POST['action']))
   {
     $action=$_POST['action'];
     switch($action)
     {
       case "�޸ĳɼ�":
         //print("�޸ĳɼ�<br>");
         //��ȡ�ɼ������������ݿ���и���
         foreach($_POST as $key=>$val)
         {
           $query="update ".$class." set grade='".$val."' where id='".$key."'";
           //print($query."<br>");
           $result=mysql_query($query,$db);
           //if($result)
         }
         print("�޸ĳɼ��ɹ���<br>");
         break;
       case "�˳�ϵͳ":
         unset($_SESSION['valid_id']);
         unset($_SESSION['valid_name']);
         session_destroy();
         header("Location:login.html");
         break;
     }
   }
   
   //�����ݿ��н��γ̶�Ӧ�ĳɼ�����ʾ����
   print("�γ�".$class."�ɼ���<br>");
   $query="select * from ".$class;
   $result=mysql_query($query,$db);
   print('<form action="teacher.php" method="post">');
   $s_grade=array();
   $s_count=0;
   while($value=mysql_fetch_array($result))
   {
     $s_grade[]=$value;
   }
   print("<br><br>"); 
   print('<form method="post">');
   //��ʾ�ɼ�
   print('<table>');
   print('<tr>');
   print('<th>ѧ��</th>');
   print('<th>����</th>');
   print('<th>�ɼ�</th>');
   print('</tr>');
   foreach($s_grade as $temp)
   {
     $s_id=$temp['id'];
     $s_name=$temp['name'];
     $s_grade=$temp['grade'];
     print('<tr>');
     print('<th>'.$s_id.'</th>');
     print('<th>'.$s_name.'</th>');
     print('<th>');
     print('<input type="text" name="'.$s_id.'" value="'.$s_grade.'" />');
     print('</th>');
     print('</tr>');
   }
   print('</table>');
   print('<input type="submit"  disabled="disabled" name="action" value="¼��ɼ�">');
   print('<input type="submit" name="action" value="�޸ĳɼ�">');
   print('<input type="submit" name="action" value="�˳�ϵͳ">');
   print('</form>');
 
  mysql_close($db);
  //
?>
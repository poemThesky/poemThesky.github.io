<?php
  session_start();
  if(!isset($_SESSION['valid_id']))
    header("Location:login.html");
  $name=$_FILES['userfile']['name'];
  $tmp=$_FILES['userfile']['tmp_name'];
  move_uploaded_file($tmp,$name);
  print("�ϴ���ҵ".$name."�ɹ�<br>");
  
//���˰�ť
  print('<form action="student.php" method="get">');
  print('<input type="submit" value="<<����"/> ');
  print('</form>');
?>